export const helperMismatchMessage = (
	expectedProtocol: number,
	expectedExecutable: string,
	actualProtocol: number,
	actualExecutable: string | undefined,
): string => `pi-computer-use helper mismatch: expected protocol ${expectedProtocol} and executable ${expectedExecutable}; got protocol ${actualProtocol} and executable ${actualExecutable ?? "unknown"}. The running helper was not restarted. Close its owning sessions and quit the old helper, then run rotom helper update explicitly. On managed Macs, set PI_COMPUTER_USE_CODESIGN_IDENTITY to an existing approved signing identity before that command. It installs to ~/Applications/pi-computer-use.app without starting it; use that path in the new session, or explicitly maintain your separate helper app and socket. ${helperUnavailableGuidance}`;

/** Model-facing next step: the mismatch does not change until a person acts. */
export const helperUnavailableGuidance =
	"Computer Use is unavailable in this session until a person restarts the helper. Do not call Computer Use tools again for this; use the browser tools for web pages, or report the blocker to the user.";

/** Asked once per session before stopping a helper that other sessions may own. */
export const helperRestartCopy = {
	title: "Computer Use helper is out of date",
	message: (actualProtocol: number, expectedProtocol: number): string =>
		`A Computer Use helper speaking protocol ${actualProtocol} is still running; this rotom needs protocol ${expectedProtocol}. Restarting it stops the old helper, and any other rotom session using Computer Use loses it until that session reconnects. Restart it now? If you decline, Computer Use stays unavailable in this session.`,
};

export const takeoverCopy = {
	unsupportedHelper: "The helper does not support safe pause/resume. Use a separately built helper; the running helper was not changed.",
	started(app: string, pid: number, expiresAt: string): string {
		return `Foreground taken for ${app} (pid ${pid}) until ${expiresAt}. Real input pauses the takeover; it resumes after 30 quiet seconds if authorization and the original window remain valid. Esc or the stop menu ends it permanently.`;
	},
};

export const brokerCopy = {
	blocked(tool: string, message: string, code: string, holder?: { agentId: string; remainingMs: number }): string {
		const held = code === "resource_busy" && holder
			? ` Held by agent ${holder.agentId} (${Math.ceil(holder.remainingMs / 1000)}s remaining).` : "";
		const next = code === "broker_unavailable"
			? " Broker availability or approval completion is unconfirmed; this does not prove another agent holds the app. Stop and inspect broker/approval diagnostics; do not automatically retry, stop another session or disable arbitration."
			: code === "resource_busy"
				? " Wait for the holder to release the app, then obtain a fresh observation before a new action."
				: " Resolve the refusal before requesting a new action.";
		return `${tool} was blocked before native input: ${message}${held}${next}`;
	},
	notDispatched: "act_ui evidence: dispatch=not_started; verification=not_reported. The lease failed before native input; this does not verify the current application state.",
};

/** Three-way app authorization card shown to the human, never to the model. */
export const approvalCopy = {
	action: (name?: string) => `Action: ${name ?? "unknown"}`,
	allowSession: "Allow for this session",
	allowOnce: "Allow this action",
	externalOpenWarning: "会用其他程序打开，可能切到前台。",
	openWarning(warning?: string): string {
		if (!warning) return approvalCopy.externalOpenWarning;
		if (warning.includes(approvalCopy.externalOpenWarning)) return warning;
		return `${warning}\n${approvalCopy.externalOpenWarning}`;
	},
	openBatch: (actions: Array<{ name: string; label?: string }>) => JSON.stringify(actions),
	allowAlways: "Always allow this app",
	deny: "Deny",
	options(): [string, string, string] {
		return [approvalCopy.allowSession, approvalCopy.allowAlways, approvalCopy.deny];
	},
	title(input: { app: string; tier: string; action: string; label?: string; sensitive?: string; warning?: string }): string {
		const lines = [`Computer Use: allow an agent to control ${input.app}? (tier: ${input.tier})`];
		lines.push(input.action);
		if (input.label) lines.push(`Target: ${JSON.stringify(input.label)}`);
		if (input.sensitive) lines.push(input.sensitive);
		if (input.warning) lines.push(input.warning);
		return lines.join("\n");
	},
};
