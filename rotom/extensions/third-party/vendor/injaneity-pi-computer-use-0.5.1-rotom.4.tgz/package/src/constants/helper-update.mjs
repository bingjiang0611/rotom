export const helperUpdateCommand = "rotom helper update";
export const helperUpdateCopy = {
	macOnly: "Helper update is supported only on macOS.",
	missingBundle: "The packaged helper app is missing. Reinstall a complete rotom package; no helper was changed.",
	wrongBundle: "Refusing a helper with an unexpected bundle or signing identifier.",
	unsafePath: "Refusing a symlink or non-canonical helper update path.",
	busy: (pids) => `Helper is still in use (pid ${pids}); no app replacement was performed. 运行 ${helperUpdateCommand}（它会询问是否停止旧 helper）。Stopping requires an interactive terminal and explicit consent; no process will be killed.`,
	stopPrompt: "停止正在运行的旧 helper？使用它的其他 rotom 会话会失去 Computer Use。[y/N] ",
	socketMismatch: "The socket does not identify the helper occupying the update target. No shutdown or app replacement was performed.",
	socketUnknown: (command) => `Helper ${command} was not acknowledged; its outcome is unknown. No app replacement or automatic shutdown retry was performed. Inspect helper occupancy before running the updater again.`,
	unknownProcesses: "Cannot establish whether the helper is in use. No helper was changed; inspect the process-check error before retrying.",
	locked: "Another helper update is in progress, or an interrupted update left a lock. Inspect it before retrying; do not remove an active lock.",
	noSign: "PI_COMPUTER_USE_NO_SIGN conflicts with an explicit signing identity. No helper was changed.",
	adhoc: "Refusing to replace an existing helper with an ad-hoc bundle. Set PI_COMPUTER_USE_CODESIGN_IDENTITY to an existing approved identity, or explicitly authorize PI_COMPUTER_USE_ALLOW_ADHOC_UPDATE=1. This does not override system security policy.",
	notInstalled: "Helper installation did not complete. Inspect the target before retrying.",
	incomplete: (backup) => `Helper replacement did not complete. The previous app is preserved at ${backup}. Inspect both paths; do not automatically replay the update.`,
	complete: (target) => `Updated helper at ${target}. No helper was started and no session was restarted. Start a new session to check protocol and permissions.`,
};
