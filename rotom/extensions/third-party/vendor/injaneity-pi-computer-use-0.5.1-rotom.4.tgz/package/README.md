# pi-computer-use

> rotom-maintained private fork (`0.5.1-rotom.4`), not an upstream release. See [provenance and changes](UPSTREAM.md). Project: [bingjiang0611/rotom](https://github.com/bingjiang0611/rotom). For the integrated product, follow the [rotom installation guide](../../docs/usage.md); do not overlay an upstream install onto its pinned dependencies. Platform descriptions below describe the component, not a rotom Windows support claim.

`pi-computer-use` lets AI agents use desktop apps on macOS, Windows, and Linux.

The macOS helper requires macOS 14 or newer.

An agent can look at an app window, understand the buttons and text inside it, and perform actions like clicking, typing, scrolling, and waiting for something to change. This is useful when the agent needs to work with a normal desktop app instead of an API, a terminal command, or a file.

New to computer use? Start with: [Wait, what exactly is Computer Use?](https://zanechee.dev/what-exactly-is-computer-use/)

## What this package does

This is a Pi extension. After installation, Pi agents get tools for:

- finding open apps and windows
- observing what is visible in a window
- searching the visible interface for text, buttons, and controls
- inspecting parts of the interface in more detail
- clicking, typing, scrolling, and pressing UI controls
- waiting for UI changes

In short: it gives an agent a controlled way to operate desktop software.

## What this package is not

`pi-computer-use` is not a replacement for app APIs or MCP servers. If an app has a reliable direct integration, use that first.

Computer use is most helpful when the only available interface is the app on screen.

## Update the rotom macOS helper

After closing its owning sessions, explicitly run `rotom helper update` (it asks whether to stop the old helper). The interactive prompt defaults to no and warns that other sessions using this helper lose Computer Use. Only explicit consent sends a socket shutdown; refusal and noninteractive use leave a running helper untouched. On a managed Mac, set `PI_COMPUTER_USE_CODESIGN_IDENTITY` to an existing approved identity first. The command signs only the install copy at `~/Applications/pi-computer-use.app`; it does not modify certificates or start/restart a helper. The updater verifies the socket identifies the target, then waits for its executable to become unoccupied before replacement. An unknown shutdown or inconclusive/still-busy process check blocks replacement; no forced termination or automatic shutdown retry is used. Session protocol mismatch can request this same stop, but never relaunches the old binary; update explicitly and open a new session. Without an identity, the packaged signature and existing ad-hoc update guard are preserved. Keep sessions closed during the update; the updater lock does not prevent external launches. See [lifecycle, custom paths and signing limits](UPSTREAM.md#helper-lifecycle-and-signing).

## Install upstream (not this fork)

The following command installs the public upstream package without the rotom fixes:

```bash
pi install npm:@injaneity/pi-computer-use
```

Start Pi and complete the platform setup flow.

On macOS, the helper is installed per user by default. Grant permissions to:

```text
~/Applications/pi-computer-use.app
```

Existing writable system-wide installs remain at `/Applications/pi-computer-use.app`.

Required macOS permissions:

- Accessibility
- Screen Recording, shown as Screen and System Audio Recording on newer macOS versions

The macOS setup flow registers the helper first, so it should already appear in both Settings panes. Enable the toggles and choose Recheck.

On Windows, use an interactive desktop session. Windows support uses the platform accessibility APIs and does not use the macOS helper app or TCC permission flow.

On Linux, run Pi inside the target user's graphical session with a working AT-SPI2 accessibility bus. AT-SPI semantic operations remain background-first. X11 additionally supports EWMH window metadata/focus, window capture, and policy-gated XTEST physical input; strict headless/background policies never use focus or XTEST. Native Wayland remains semantic-only; diagnostics reads portal capability properties without creating a session, and interactive portal use is disabled. See [Linux support](./docs/linux.md) for the exact capability matrix and portal status.

Use `/computer-use` inside Pi to show the active configuration and where it came from.

## Main tools

- `find_roots`
- `observe_ui`
- `search_ui`
- `expand_ui`
- `inspect_ui`
- `act_ui`
- `read_text`
- `wait_for`

See [docs/usage.md](./docs/usage.md) for the full tool reference.

## Documentation

- [Usage](./docs/usage.md)
- [Architecture](./docs/architecture.md)
- [Configuration](./docs/configuration.md)
- [Development](./docs/development.md)
- [Troubleshooting](./docs/troubleshooting.md)
- [Linux support](./docs/linux.md)
- [Fork maintenance and verification boundary](./UPSTREAM.md)

## Development status

The architecture is centered on immutable, state-scoped observations. Desktop surfaces and CDP pages form one multi-root forest; progressive outline queries remain cached, while live work is ordered per physical resource so independent roots can run in parallel. `act_ui` accepts one or more intent steps, preserves focus across dependent input, verifies delivery, recovers safely, stores one complete successor state, and returns a compact diff when identity confidence allows. Older direct tools such as `screenshot`, `click`, `set_text`, and `computer_actions` are no longer part of the public extension surface.

## License

MIT
