#!/usr/bin/env node

import { spawn } from "node:child_process";
import fs from "node:fs/promises";
import os from "node:os";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { macosSourceFiles } from "./macos-sources.mjs";

const rootDir = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const macosSourcePaths = macosSourceFiles.map((file) => path.join(rootDir, "native", "macos", file));
const windowsCrateDir = path.join(rootDir, "native", "windows", "bridge-rs");
const linuxCrateDir = path.join(rootDir, "native", "linux", "bridge-rs");
const linuxTargets = { x64: "x86_64-unknown-linux-gnu", arm64: "aarch64-unknown-linux-gnu" };
const archTriples = {
	arm64: "arm64-apple-macosx",
	x64: "x86_64-apple-macosx",
};
const deploymentTarget = "14.0";
const frameworks = ["ApplicationServices", "AppKit", "ScreenCaptureKit", "Foundation", "SwiftUI"];
const defaultCodeSignIdentifier = "com.injaneity.pi-computer-use";

async function exists(filePath) {
	try {
		await fs.access(filePath);
		return true;
	} catch {
		return false;
	}
}

function getArg(name) {
	const index = process.argv.indexOf(name);
	if (index >= 0 && index + 1 < process.argv.length) {
		return process.argv[index + 1];
	}
	return undefined;
}

function hasArg(name) {
	return process.argv.includes(name);
}

function normalizeArch(arch) {
	if (arch === "universal" || arch === "all") return arch;
	if (arch === "arm64" || arch === "x64") return arch;
	throw new Error(`Unsupported architecture '${arch}'. Supported: arm64, x64, universal, all.`);
}

async function run(command, args) {
	await new Promise((resolve, reject) => {
		const child = spawn(command, args, { stdio: "inherit" });
		child.on("error", reject);
		child.on("close", (code) => {
			if (code === 0) {
				resolve();
				return;
			}
			reject(new Error(`Command failed (${code}): ${command} ${args.join(" ")}`));
		});
	});
}

function defaultOutputPath(arch) {
	return path.join(rootDir, "prebuilt", "macos", arch, "bridge");
}

function moduleCachePath(arch) {
	return path.join(os.tmpdir(), `pi-computer-use-swift-module-cache-${arch}`);
}

function swiftArgsForArch(arch, outputPath) {
	const args = [
		"swiftc",
		"-target",
		`${archTriples[arch]}${deploymentTarget}`,
		"-module-cache-path",
		moduleCachePath(arch),
		"-O",
	];
	for (const framework of frameworks) args.push("-framework", framework);
	args.push(...macosSourcePaths, "-o", outputPath);
	return args;
}

async function signBinary(outputPath) {
	if (hasArg("--no-sign") || process.env.PI_COMPUTER_USE_NO_SIGN === "1") {
		return;
	}

	const identity = getArg("--sign-identity") ?? process.env.PI_COMPUTER_USE_CODESIGN_IDENTITY ?? "-";
	const identifier = getArg("--sign-identifier") ?? process.env.PI_COMPUTER_USE_CODESIGN_IDENTIFIER ?? defaultCodeSignIdentifier;
	const args = ["--force", "-i", identifier];
	if (hasArg("--hardened-runtime")) {
		args.push("--options", "runtime");
	}
	if (hasArg("--timestamp")) {
		args.push("--timestamp");
	} else {
		args.push("--timestamp=none");
	}
	args.push("--sign", identity, outputPath);
	await run("codesign", args);
}

async function buildForArch(arch, outputPath) {
	await fs.mkdir(path.dirname(outputPath), { recursive: true });
	console.log(`Building native helper for ${arch}...`);
	await run("xcrun", swiftArgsForArch(arch, outputPath));
	await fs.chmod(outputPath, 0o755);
	await signBinary(outputPath);
	console.log(`Built helper at ${outputPath}`);
}

async function buildUniversal(outputPath) {
	const tempDir = await fs.mkdtemp(path.join(os.tmpdir(), "pi-computer-use-build-"));
	const x64Output = path.join(tempDir, "bridge-x64");
	const arm64Output = path.join(tempDir, "bridge-arm64");
	await buildForArch("x64", x64Output);
	await buildForArch("arm64", arm64Output);
	await fs.mkdir(path.dirname(outputPath), { recursive: true });
	await run("lipo", ["-create", "-output", outputPath, x64Output, arm64Output]);
	await fs.chmod(outputPath, 0o755);
	await signBinary(outputPath);
	console.log(`Built universal helper at ${outputPath}`);
	await fs.rm(tempDir, { recursive: true, force: true });
}

/**
 * Return the actual cargo binary path, handling platform suffix differences.
 * On Windows, the binary is named "windows-bridge.exe"; on other platforms it's "windows-bridge".
 */
function windowsBinaryPath(crateDir, target) {
	const releaseDir = target
		? path.join(crateDir, "target", target, "release")
		: path.join(crateDir, "target", "release");
	return path.join(releaseDir, "windows-bridge.exe");
}

async function buildWindowsHelper(prebuiltOutput) {
	const target = getArg("--target");
	if (process.platform !== "win32" && !target?.includes("windows")) {
		throw new Error("Refusing to label a host binary as Windows. Build on Windows or pass an explicit Windows --target triple.");
	}
	const prebuiltDir = prebuiltOutput
		? path.resolve(process.cwd(), prebuiltOutput, "..")
		: path.join(rootDir, "prebuilt", "windows");
	const manifestPath = path.join(windowsCrateDir, "Cargo.toml");

	console.log("Building Windows helper with cargo...");
	const cargoArgs = [
		"build",
		"--release",
		"--manifest-path",
		manifestPath,
	];
	if (target) cargoArgs.push("--target", target);
	await run("cargo", cargoArgs);

	await fs.mkdir(prebuiltDir, { recursive: true });

	const cargoOutput = windowsBinaryPath(windowsCrateDir, target);
	const handle = await fs.open(cargoOutput, "r");
	try {
		const signature = Buffer.alloc(2);
		await handle.read(signature, 0, 2, 0);
		if (signature.toString("ascii") !== "MZ") {
			throw new Error(`Cargo output is not a Windows PE executable: ${cargoOutput}`);
		}
	} finally {
		await handle.close();
	}
	const prebuiltDest = path.join(prebuiltDir, "windows-bridge.exe");
	await fs.copyFile(cargoOutput, prebuiltDest);
	await fs.chmod(prebuiltDest, 0o755);
	console.log(`Built Windows helper at ${prebuiltDest}`);
}

function linuxBinaryPath(crateDir, target) {
	const targetDir = target ? path.join("target", target) : "target";
	return path.join(crateDir, targetDir, "release", "linux-bridge");
}

function defaultLinuxOutputPath(arch) {
	return path.join(rootDir, "prebuilt", "linux", arch, "linux-bridge");
}

async function buildLinuxForArch(arch, outputPath) {
	const explicitTarget = getArg("--target");
	if (explicitTarget && !explicitTarget.includes("linux")) throw new Error(`Linux builds require a Linux --target triple, got ${explicitTarget}.`);
	const target = explicitTarget ?? (process.platform === "linux" && process.arch === arch ? undefined : linuxTargets[arch]);
	console.log(`Building Linux helper for ${arch} with cargo...`);
	const cargoArgs = ["build", "--release", "--manifest-path", path.join(linuxCrateDir, "Cargo.toml")];
	if (target) cargoArgs.push("--target", target);
	await run("cargo", cargoArgs);
	const cargoOutput = linuxBinaryPath(linuxCrateDir, target);
	const header = await fs.readFile(cargoOutput).then((data) => data.subarray(0, 20));
	if (header.length < 20 || !header.subarray(0, 4).equals(Buffer.from([0x7f, 0x45, 0x4c, 0x46]))) throw new Error(`Cargo output is not a Linux ELF executable: ${cargoOutput}`);
	const machine = header.readUInt16LE(18);
	const expectedMachine = arch === "x64" ? 0x3e : 0xb7;
	if (machine !== expectedMachine) throw new Error(`Cargo output architecture does not match ${arch}: ${cargoOutput}`);
	await fs.mkdir(path.dirname(outputPath), { recursive: true });
	await fs.copyFile(cargoOutput, outputPath);
	await fs.chmod(outputPath, 0o755);
	console.log(`Built Linux helper at ${outputPath}`);
}

async function buildLinuxHelper() {
	const arch = normalizeArch(getArg("--arch") ?? process.arch);
	if (arch === "universal") throw new Error("Linux does not support --arch universal. Use x64, arm64, or all.");
	const outputArg = getArg("--output");
	if (arch === "all") {
		if (outputArg) throw new Error("--output is not supported with --arch all. Use a single architecture for one output.");
		for (const nextArch of ["x64", "arm64"]) await buildLinuxForArch(nextArch, defaultLinuxOutputPath(nextArch));
		return;
	}
	await buildLinuxForArch(arch, outputArg ? path.resolve(process.cwd(), outputArg) : defaultLinuxOutputPath(arch));
}

async function main() {
	const explicitPlatform = getArg("--platform");

	if (explicitPlatform === "windows") {
		await buildWindowsHelper(getArg("--output"));
		return;
	}

	if (explicitPlatform === "linux") {
		await buildLinuxHelper();
		return;
	}

	if (explicitPlatform === "darwin") {
		// Fall through to macOS build logic below.
	} else if (process.platform === "win32") {
		await buildWindowsHelper(getArg("--output"));
		return;
	} else if (process.platform === "linux") {
		await buildLinuxHelper();
		return;
	} else if (process.platform !== "darwin") {
		console.log(
			`Skipping native build: unsupported platform "${process.platform}". ` +
				"Use --platform windows or --platform linux to build a helper, or run on macOS for the macOS helper.",
		);
		return;
	}

	const arch = normalizeArch(getArg("--arch") ?? process.arch);
	const outputArg = getArg("--output");

	if (arch === "all") {
		if (outputArg) {
			throw new Error("--output is not supported with --arch all. Use a single architecture for one output.");
		}
		for (const nextArch of ["x64", "arm64"]) {
			await buildForArch(nextArch, defaultOutputPath(nextArch));
		}
		// The installer prefers this bundle over per-arch executables. Build all
		// three from the same sources so an old signed app cannot shadow a fix.
		const bundle = path.join(rootDir, "prebuilt", "macos", "universal", "pi-computer-use.app");
		const contents = path.join(bundle, "Contents");
		await fs.mkdir(path.join(contents, "MacOS"), { recursive: true });
		await run("lipo", ["-create", "-output", path.join(contents, "MacOS", "bridge"), defaultOutputPath("arm64"), defaultOutputPath("x64")]);
		const { version } = JSON.parse(await fs.readFile(path.join(rootDir, "package.json"), "utf8"));
		await fs.writeFile(path.join(contents, "Info.plist"), `<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
<key>CFBundleIdentifier</key><string>${defaultCodeSignIdentifier}</string>
<key>CFBundleName</key><string>pi-computer-use</string>
<key>CFBundleExecutable</key><string>bridge</string>
<key>CFBundlePackageType</key><string>APPL</string>
<key>CFBundleShortVersionString</key><string>${version.split("-")[0]}</string>
<key>CFBundleVersion</key><string>${version.split("-")[0]}</string>
<key>RotomForkVersion</key><string>${version}</string>
<key>LSMinimumSystemVersion</key><string>${deploymentTarget}</string>
<key>LSUIElement</key><true/>
<key>NSHighResolutionCapable</key><true/>
</dict></plist>
`);
		await signBinary(bundle);
		return;
	}

	const outputPath = outputArg ? path.resolve(process.cwd(), outputArg) : defaultOutputPath(arch);
	if (arch === "universal") {
		await buildUniversal(outputPath);
		return;
	}

	await buildForArch(arch, outputPath);
}

main().catch((error) => {
	console.error(error instanceof Error ? error.message : String(error));
	process.exit(1);
});
