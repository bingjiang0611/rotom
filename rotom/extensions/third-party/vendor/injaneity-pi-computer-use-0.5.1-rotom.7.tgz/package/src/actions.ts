import { SEMANTIC_ACTION_NAMES, type MouseButtonName, type SemanticActionName, type UiAction } from "./contract.ts";
import type { OpenTarget } from "./open-target.ts";
import type { OutlineNode } from "./outline.ts";
import { toFiniteNumber } from "./platform/coerce.ts";

export type ActionTarget = { ref: string } | { x: number; y: number } | { focus: { x: number; y: number } };

type SemanticActionParams = {
	option?: string;
	checked?: boolean;
	value?: number;
	openTarget?: OpenTarget;
	openApproved?: boolean;
};

export type PreparedAction =
	| { action: "press" | "click"; target: ActionTarget; params: { button?: MouseButtonName; clickCount?: number }; establishesFocus: boolean; usesCurrentFocus: false; needsForeground: boolean }
	| { action: "setText"; target: ActionTarget; params: { text: string }; establishesFocus: false; usesCurrentFocus: false; needsForeground: false }
	| { action: "typeText"; target: ActionTarget; params: { text: string }; establishesFocus: false; usesCurrentFocus: boolean; needsForeground: false }
	| { action: "keypress"; target: ActionTarget; params: { keys: string[] }; establishesFocus: false; usesCurrentFocus: boolean; needsForeground: false }
	| { action: "scroll"; target: ActionTarget; params: { scrollX: number; scrollY: number }; establishesFocus: false; usesCurrentFocus: false; needsForeground: false }
	| { action: "drag"; target: ActionTarget; params: { path: Array<{ x: number; y: number }> }; establishesFocus: false; usesCurrentFocus: false; needsForeground: false }
	| { action: "moveMouse"; target: ActionTarget; params: Record<string, never>; establishesFocus: false; usesCurrentFocus: false; needsForeground: false }
	| { action: "hover"; target: ActionTarget; params: { delivery?: "l2" }; establishesFocus: false; usesCurrentFocus: false; needsForeground: false }
	| {
		action: SemanticActionName;
		target: { ref: string };
		params: SemanticActionParams;
		establishesFocus: false;
		usesCurrentFocus: false;
		needsForeground: false;
	}
	| { action: "wait"; params: { ms: number }; establishesFocus: false; usesCurrentFocus: false; needsForeground: false };

export interface ActionState {
	currentFocus: boolean;
}

export interface ActionEnvironment {
	headless: boolean;
	image?: { width: number; height: number };
	node(ref: string): OutlineNode;
	center(node: OutlineNode): { x: number; y: number };
	validatePoint(x: number, y: number, label?: string): void;
}

function mouseButton(value: unknown): MouseButtonName {
	return value === "right" || value === "middle" ? value : "left";
}

function clickCount(value: unknown, fallback = 1): number {
	return Math.max(1, Math.min(3, Math.round(toFiniteNumber(value, fallback))));
}

function scrollDelta(value: unknown): number {
	return Math.max(-10_000, Math.min(10_000, Math.round(toFiniteNumber(value, 0))));
}

function keys(value: unknown): string[] {
	if (!Array.isArray(value) || value.length === 0) throw new Error("keypress.keys must contain at least one key.");
	return value.map((key) => String(key));
}

function path(value: UiAction["path"], env: ActionEnvironment): Array<{ x: number; y: number }> {
	if (!Array.isArray(value) || value.length < 2) throw new Error("drag.path must contain at least two points.");
	return value.map((point, index) => {
		const x = Array.isArray(point) ? toFiniteNumber(point[0], NaN) : toFiniteNumber(point?.x, NaN);
		const y = Array.isArray(point) ? toFiniteNumber(point[1], NaN) : toFiniteNumber(point?.y, NaN);
		env.validatePoint(x, y, `Drag point ${index + 1}`);
		return { x, y };
	});
}

function nativeTarget(action: UiAction, operation: PreparedAction["action"], env: ActionEnvironment): ActionTarget {
	if (action.ref?.trim()) {
		const node = env.node(action.ref.trim());
		const semanticClick = operation === "click" || operation === "press";
		if (semanticClick && node.isTextInput) {
			const point = env.center(node);
			env.validatePoint(point.x, point.y);
			return point;
		}
		const onlyIncidentalActions = node.actions.every((candidate) => candidate === "AXShowMenu" || candidate === "AXScrollToVisible");
		if (node.wireRef && !node.pictureOnly && (!semanticClick || node.canPress || node.canFocus || node.canSetValue || !onlyIncidentalActions)) {
			return { ref: node.wireRef };
		}
		const point = env.center(node);
		env.validatePoint(point.x, point.y);
		return point;
	}
	const x = toFiniteNumber(action.x, NaN);
	const y = toFiniteNumber(action.y, NaN);
	if (Number.isFinite(x) && Number.isFinite(y)) {
		env.validatePoint(x, y);
		return { x, y };
	}
	if (operation === "drag" && action.path?.length) return path(action.path, env)[0];
	throw new Error(`${operation} requires either ref or both x and y.`);
}

/**
 * Semantic actions are accessibility operations on one element: they need a wire
 * ref, not a point. Refusing a coordinate here keeps "press where I guessed"
 * from being silently substituted for "check the box".
 */
function semanticTarget(action: UiAction, env: ActionEnvironment): { ref: string } {
	if (!action.ref?.trim()) throw new Error(`${action.action} requires an element ref; coordinates cannot express a semantic action.`);
	const node = env.node(action.ref.trim());
	if (!node.wireRef || node.pictureOnly) throw new Error(`${action.action} needs an element exposed through the accessibility tree; ${action.ref} is picture-only or unmapped.`);
	return { ref: node.wireRef };
}

function focusedTarget(env: ActionEnvironment): ActionTarget {
	if (!env.image) throw new Error("Focused keyboard input requires an image-bearing state.");
	return { focus: { x: Math.floor(env.image.width / 2), y: Math.floor(env.image.height / 2) } };
}

function containsEditable(node: OutlineNode): boolean {
	if (node.canSetValue || node.role.toLowerCase().includes("text")) return true;
	return node.children.some(containsEditable);
}

export function prepareAction(action: UiAction, state: ActionState, env: ActionEnvironment): PreparedAction {
	const operation = action.action;
	if (SEMANTIC_ACTION_NAMES.has(operation)) {
		const target = semanticTarget(action, env);
		if (operation === "open" && !env.node(action.ref!).actions.includes("AXOpen")) {
			throw new Error("open requires a freshly observed AXOpen capability; it is not a click fallback.");
		}
		const params: SemanticActionParams = {};
		if (operation === "select" && action.option?.trim()) params.option = action.option.trim();
		if (operation === "setChecked") {
			if (typeof action.checked !== "boolean") throw new Error("setChecked requires checked: true or false.");
			params.checked = action.checked;
		}
		if (operation === "setValue") {
			const value = toFiniteNumber(action.value, NaN);
			if (!Number.isFinite(value)) throw new Error("setValue requires a numeric value.");
			params.value = value;
		}
		return { action: operation, target, params, establishesFocus: false, usesCurrentFocus: false, needsForeground: false };
	}
	const usesCurrentFocus = !env.headless && state.currentFocus && !action.ref && (operation === "typeText" || operation === "keypress");
	const target = usesCurrentFocus ? focusedTarget(env) : nativeTarget(action, operation, env);
	const establishesFocus = !env.headless && Boolean(action.ref) && (operation === "click" || operation === "press") && containsEditable(env.node(action.ref!));
	const needsForeground = !env.headless && (operation === "click" || operation === "press") && "x" in target;

	switch (operation) {
		case "press":
		case "click": return { action: operation, target, params: { button: mouseButton(action.button), clickCount: clickCount(action.clickCount) }, establishesFocus, usesCurrentFocus: false, needsForeground };
		case "setText": return { action: operation, target, params: { text: action.text ?? "" }, establishesFocus: false, usesCurrentFocus: false, needsForeground: false };
		case "typeText": return { action: operation, target, params: { text: action.text ?? "" }, establishesFocus: false, usesCurrentFocus, needsForeground: false };
		case "keypress": return { action: operation, target, params: { keys: keys(action.keys) }, establishesFocus: false, usesCurrentFocus, needsForeground: false };
		case "scroll": return { action: operation, target, params: { scrollX: scrollDelta(action.scrollX), scrollY: scrollDelta(action.scrollY) }, establishesFocus: false, usesCurrentFocus: false, needsForeground: false };
		case "drag": return { action: operation, target, params: { path: path(action.path, env) }, establishesFocus: false, usesCurrentFocus: false, needsForeground: false };
		case "moveMouse": return { action: operation, target, params: {}, establishesFocus: false, usesCurrentFocus: false, needsForeground: false };
		case "hover": return { action: operation, target, params: {}, establishesFocus: false, usesCurrentFocus: false, needsForeground: false };
	}
}

// rotom fork enhancement (see UPSTREAM.md, "speculative foreground retry"):
//
// The speculative foreground re-dispatch re-posts keyboard events for
// typeText/keypress that were ALREADY delivered once in the background attempt.
// A "didnt" outcome here only means "no observed value change" (evidence.value
// did not change within the short post-input read); with async editors or
// delayed AX updates the first input may still have taken effect, so an
// automatic second dispatch risks duplicated input. rotom's contract is to
// perform an external write once and return didnt/unknown rather than replay it,
// letting the model re-observe and decide. This speculative retry is therefore
// disabled by default; the explicit `foreground_required` path in helperAct
// (where the native layer proved the write was NOT applied) is unaffected.
//
// Set ROTOM_CU_SPECULATIVE_FOREGROUND_RETRY=1 to restore the upstream behaviour.
export function canRetryInForeground(
	action: PreparedAction,
	outcome: "worked" | "didnt" | "unknown",
	headless: boolean,
	env: Record<string, string | undefined> = process.env,
): boolean {
	const optedIn = /^(?:1|true|yes)$/iu.test((env.ROTOM_CU_SPECULATIVE_FOREGROUND_RETRY ?? "").trim());
	if (!optedIn) return false;
	return !headless && outcome === "didnt" && (action.action === "typeText" || action.action === "keypress");
}

export function outcomeAfterCheck(current: "worked" | "didnt" | "unknown", check: "verified" | "preexisting" | "failed"): "worked" | "didnt" | "unknown" {
	if (check === "verified") return "worked";
	if (check === "failed") return "didnt";
	return current;
}

export function outcomeAfterObservedValues(
	current: "worked" | "didnt" | "unknown",
	actions: UiAction[],
	valueForRef: (ref: string) => string | undefined,
): "worked" | "didnt" | "unknown" {
	if (actions.length === 0 || actions.some((action) => action.action !== "setText" || !action.ref)) return current;
	const matches = actions.every((action) => valueForRef(action.ref!) === (action.text ?? ""));
	return matches ? "worked" : current;
}
