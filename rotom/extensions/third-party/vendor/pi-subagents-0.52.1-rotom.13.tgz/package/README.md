# rotom-subagents

rotom 独立维护的 Subagent 组件，源码单源是本目录。它是 `pi-subagents` 的私有维护分支，**不是 Pi fork**。保留 npm/internal ID `pi-subagents`，避免无关协议与资源身份迁移；版本从 `0.52.1-rotom.0` 独立演进，不自动合并上游。

首次导入为已验证的 `0.52.1-dev-agent-owned-flat.7`：213 TS 文件逐字节保持不变。来源、版权和维护差异见 [UPSTREAM.md](UPSTREAM.md) / `IMPORT.json`，原始 README 保存在 [docs/upstream-readme.md](docs/upstream-readme.md)。历史八层 patch 仅用于旧版本比较，不是本组件的构建输入。

## `0.52.1-rotom.12`：Linux 跨重启 store 身份

Linux 的 mount device ID 也可能在重启后重新编号，已在 Btrfs/device-mapper 上复现。本版将 v3 store 已有的 device topology 双射校验扩展到全部受支持的 POSIX 平台：只接受四个持久化 device ID 到当前 ID 的一致映射，路径、四个 inode、owner、权限与 store ID 仍精确校验；marker 保持只读，不迁移、不重写，也不授权恢复或重放旧工作。

## `0.52.1-rotom.11`：原生 ephemeral 工具面

组件入口可显式选择 `{ surface: "ephemeral" }`；schema、描述、action admission 与结果证据由组件定义，不再由产品 registerTool 代理修改。默认 standalone 入口保持宽工具面；执行 scope 的原有校验不变。产品仍选择命令/快捷键、model-only 暴露与宿主发布 fence。

## 边界

- 只通过 Pi 公开 API/exports 接入；默认验证 Pi 0.85.1、Node 24.18.0。
- 修改 `src/`，不要修改任何 installed `node_modules`。
- 产品通过固定归档安装本组件；本目录不会被 launcher 自动发现或热加载。个人默认 scope 由新进程的启动环境选择，不迁移活跃会话。
- 首次导入保持 runtime 代码、exports 与内置资源不变；后续兼容性变化见下方版本说明。保留的上游能力不代表 rotom 暴露它们。
- 默认 scope 不变。新进程显式选择 `owned-process-groups-v2` 前先读 [执行范围](docs/owned-execution.md)。容量、历史关闭、恢复授权分开；unknown 不重放，不迁移存活会话。
- MIT 原始版权/许可证保留；`private:true`，不发布 npm。上游安全修复、许可证和 Pi/Node 兼容变化仍需人工关注。

## `0.52.1-rotom.1`：常用 agent 的 scoped 配置

`worker`、`scout`、`reviewer` 现在明确声明空 ambient extensions 与 `defaultContext: fresh`，工具白名单不扩大，仍保留模型/工具的原生用户与项目 overrides。只改这三个内置 profile，不自动修补自定义 agent、不替换显式 fork 请求、不移除 admission 拒绝规则。其他未适配 agent 在 owned scope 下可能拒绝启动。213 TS 执行代码保持原样。

## `0.52.1-rotom.2`：macOS 跨重启 store 身份

macOS 的 mount device ID 可能在重启后重新编号。store 现在只在 Darwin 上接受四个持久化 device ID 到当前 device ID 的一致双射；路径、四个 inode、owner、权限、store ID，以及进程存活期间的实际 device 仍精确校验。Linux 继续要求持久化 device ID 精确一致。既有 v3 marker 只读复用，不迁移、不重写，也不授权恢复或重放旧工作。

## `0.52.1-rotom.3`：隔离子进程的 Qoder provider

产品 launcher 在资源校验后固定内部 `ROTOM_SUBAGENT_QODER_EXTENSION` 路径。共享 launch plan 仅为选定 `qoder/*` 的子进程加载该 provider，并将它纳入 launch extension identity/digest；preflight、同步、异步和 workflow 使用同一计划。空 `extensions` 仍关闭 ambient discovery，不继承父工具、不换模型、不复制凭据。`ROTOM_QODER=0` 或 capability ceiling 禁止扩展时拒绝本次启动；非 Qoder 模型与非产品调用方保持原行为。其他自定义 provider 仍需显式 `subagentOnlyExtensions`，未实现通用 provider 继承。

离线回归使用真实 Pi CLI/RPC、隔离 HOME 和合成凭据，证明 `qoder/ultimate:high` 在禁用 ambient extensions 时可选择；未发送真实 Qoder 推理，不证明账号目录、额度或远端评审成功。旧会话/失败任务不自动重放，正在使用的安装不原地覆盖。

## `0.52.1-rotom.4`：精简产品面与原任务诊断

- 产品 wrapper 使用自有简短说明与单份提示，不再叠加上游全文。字段说明不再引导已禁用的 mission/project/watchdog 配置；owned scope 的模型 schema 只呈现 fresh/async、隐藏 worktree/gate/isolation，原始 SDK 请求仍过原执行校验。
- targeted async `status` 复用原 resume preflight 与 transcript reader，显示任务摘要、进程终态、历史 registered-resource closure、恢复拒绝原因和 8 行输出尾部。preflight 不是启动授权；canonical lease 占用仍拒绝恢复，业务效果和逃逸后代仍未验证。输出沿用当前会话/路径边界，不新增 inspector。
- 删除 schedule manager、专属 executor/selector 与 goal-mission continuation driver；移除启动/完成时的 mission observer 扫描和同步。**兼容性变化也适用于显式 legacy scope**：旧 `schedule.*`、自动 goal-mission 通知与 `scheduledRuns` 不再执行，历史文件不删除、不迁移、不重放。手动历史 mission/status reader、共享 workflow helper、导出的 project-panes API 与现有 fleet 仍保留，不能把本次裁剪宣称为整套 mission/inspector 源码已删除。
- 不改变停止、owner lifeline、受控进程组、lease 或恢复门禁；不升级存活安装。真实模型业务效果与桌面 UI 未验收。

## `0.52.1-rotom.5`：保留 unknown 终态证据

在 `.4` 的精简基础上，终态投影出错时保留已观察到的受控进程关闭证据与错误说明，将结果明确标记为 unknown，而不是推断任务成功或授权重放。本版重新归档当前源码，使后续终态修复实际进入产品；不覆盖旧 `.4` 归档，不迁移存活安装。它属于后续开发，不包含在已冻结的 rotom `0.1.17` 安装包中。

## `0.52.1-rotom.9`：父运行时退出前等待关闭证明

正常退出、reload、new/resume 或 SDK dispose 时，先暂停当前扩展运行时实际启动的异步 runner，等待真实 `close` 回调完成终态证据处理，再清理运行时。只保留当前进程中的 ChildProcess 对象，不按历史 PID 补发信号；其他运行时的任务不受影响。回收开始后拒绝新 writer，正常关闭后可由新运行时恢复原 canonical session。后台任务不再跨越其所属运行时的销毁继续执行。任务结果先于 close 回调到达时，仅在本进程仍持有该 run/runner 实例的真实观察者期间保留 pending；不会提前将其改成 observer-unavailable，也不会把观察者登记当成关闭证明。

强杀、异常 owner loss、缺失/写入失败的证据仍是 unknown，不从候选记录或 PID 消失推断历史退出；不补写旧任务的成功证明、不自动恢复旧任务。源码版本不会热更新当前安装。验证、首次失败与剩余限制见[父运行时关闭修复](../../docs/agent/subagent-parent-shutdown.md)。

## `0.52.1-rotom.10`：内置角色可在 owned scope 启动

会话复盘发现 `delegate` 在 owned scope 下 6/6 启动失败、`researcher` 1/1 失败，原因都是缺少显式 `extensions`。本版调整内置角色：

- `delegate` 声明空 `extensions` 与 `defaultContext: fresh`，工具白名单不变。
- `oracle`（别名 `advisor`）改为 `defaultContext: fresh`、空 `extensions`，任务由父会话写成决策简报（目标/验收、已定决策、约束、方案、相关文件、具体问题）；仍只读，不再依赖 fork。
- `reviewer` 增加 `bash`，提示词限定只读检查（diff/log/rg、运行现有测试与类型检查），禁止写文件、Git 写操作、安装和网络；这是提示约束，不是沙箱。
- 删除 `researcher`：它依赖的 `web_search`/`fetch_content` 在 rotom 中不存在。需要网页检索时由父会话自行完成，或配置显式声明 web 工具与 `extensions` 的自定义 agent。

自定义 agent、显式 fork 请求与 admission 拒绝规则不变。

## 开发

在本目录运行；依赖是固定版本及本目录 lockfile，勿复制维护者 node_modules：

```sh
npm ci --ignore-scripts --no-audit --no-fund
npm test                 # 打包/路径/来源合同 + 19 项 wait/drain 边界
npm run test:sdk         # 本源码快照：真实进程、local faux、admission/owner loss
npm run test:compat      # 历史 reader/lease/capacity 等兼容回归
npm run typecheck        # --listFilesOnly 绑定当前快照，不使用旧 tsconfig
# 或 npm run test:all
```

当前公开 checkout 的 `test:compat` 仍引用已归档或不存在的顶层历史测试路径（首个缺失文件是 `subagent-owned-flat.test.mjs`），会在测试发现阶段失败；这不是已通过的兼容门。本次不删除或跳过历史断言来掩盖问题。现行单测、真实进程/SDK 与 typecheck 分别执行，产品侧继续运行当前 ownership/lifeline 回归、default/full loader smoke 与 footprint 合同；这些不替代缺失的历史兼容证据。若仍需该旧层对照矩阵，须先明确要支持的历史版本，再恢复其完整、可审计的 fixtures，而非猜路径或恢复已撤销能力。

当前源码的测试快照直接复制本目录，不应用补丁、不从旧归档抽取实现。`test:compat` 中旧 reader/对照版本仍由历史 fixtures 生成，这是比较证据，不是新源码的依赖。复用仓库的 verifier 与测试驱动，不另建 Pi 框架。无需私有 upstream checkout 或真实账号；测试使用隔离 HOME，无远端模型授权。

## 打包与独立产品接入

发行前用 `npm version --no-git-tag-version 0.52.1-rotom.N` 显式升版本（同步 lock），不重用已有归档身份。先跑上面的检查；`pack:release` 校验 lock、payload、实际 tgz 隐私扫描，不复制 dependencies、tests、脚本或运行记录，不覆盖旧产物：

```sh
OUT=$(mktemp -d "${TMPDIR:-/tmp}/rotom-subagents-output.XXXXXX")
OUT=$(cd "$OUT" && pwd -P)
npm run pack:release -- "$OUT"
```

生成 `pi-subagents-<version>.tgz` 与 `.tgz.json` receipt（源码摘要、完整性、审计）。下面在**新副本**同步 product manifest、lock/shrinkwrap、archive、product-config；不编辑当前仓库运行时声明或安装：

```sh
npm run stage:product -- \
  --archive "$OUT/pi-subagents-0.52.1-rotom.0.tgz" \
  --output "$OUT/product-source" --revision HEAD \
  --product-version 0.1.0-rotom-subagents.0
(cd "$OUT/product-source/rotom" && npm run pack:release -- "$OUT")
PREFIX="$OUT/install"
npm install --prefix "$PREFIX" --ignore-scripts --no-audit --no-fund \
  "$OUT/rotom-0.1.0-rotom-subagents.0.tgz"
mkdir -m 700 "$OUT/product-evidence"
npm run test:product -- "$PREFIX" "$OUT/product-evidence"
```

`--revision` 是固定的 committed 产品输入；dirty WIP 不混入。新组件版本/产品版本每次发行递增，示例版本仅对应首次导入。`test:product` 跑实际 npm bin 的六种本地 SSE 场景，证明 cwd/argv、等待/自动等待、native resume 和 mixed/foreground workflow，不冒充真实模型或业务效果验证。发布前还需按根维护门禁执行 distribution/default/full smoke、升级/卸载及对应 OS 验证；上述命令不自动升级存活安装。

## 后续维护

1. 在本目录改源码并补语义回归；不用更新 `IMPORT.json` 来掩盖与原始导入的差异。
2. 协议、scope、lease 与 resource identity 改动扩大验证，继续保留 unknown/取消/外部写不重放边界。
3. 先单独改行为，再另行删除不需要的旧能力；不要把初次内化与大规模裁剪绑在一起。
4. 上游只人工挑选必要修复，记录来源与许可证，独立测试；不追版本号自动覆盖本地实现。
